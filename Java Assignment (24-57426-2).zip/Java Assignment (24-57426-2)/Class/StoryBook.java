package Class;
public class StoryBook extends Book {
    private String category;

    public StoryBook() {}

    public StoryBook(String bookTitle, String authorName, double price, int availableQuantity, String category) {
        super( bookTitle, authorName, price, availableQuantity);
        this.category = category;
    }

    public void setCategory(String category) { this.category = category; }
    public String getCategory() { return category; }

    
    public void showDetails() {
        System.out.println("Title: " + bookTitle);
        System.out.println("Author: " + authorName);
        System.out.println("Price: " + price);
        System.out.println("Available Quantity: " + availableQuantity);
        System.out.println("Category: " + category);
    }
}
