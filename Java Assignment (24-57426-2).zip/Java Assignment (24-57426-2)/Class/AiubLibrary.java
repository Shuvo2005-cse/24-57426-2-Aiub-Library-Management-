package Class;

public class AiubLibrary {
    private String libraryName;
    private int libraryHour;
    private TextBook[] b1;
    private StoryBook[] b2;
    private int totalCount; 
    private int count;      

    public AiubLibrary() {
        System.out.println("Default Constructor of Library");
    }

    public AiubLibrary(String libraryName, int libraryHour, int no) {
        System.out.println("Valued Constructor of Library");
        this.libraryName = libraryName;
        this.libraryHour = libraryHour;

        b1 = new TextBook[no];
        b2 = new StoryBook[no];
    }

    public void setValues(String libraryName, int libraryHour) {
        this.libraryName = libraryName;
        this.libraryHour = libraryHour;
    }

    public void addTextBook(TextBook ob) {
        if (totalCount < b1.length) {
            b1[totalCount] = ob;
			totalCount++;
        } else {
            System.out.println("No space left for TextBooks.");
        }
    }

    public void deleteTextBook(TextBook ob) {
        for (int i = 0; i < totalCount; i++) {
            if (b1[i] == ob) {
                b1[i] = b1[--totalCount];
                break;
            }
        }
    }

    public void addStoryBook(StoryBook ob) {
        if (count < b2.length) {
            b2[count] = ob;
			count++;
        } else {
            System.out.println("No space left for StoryBooks.");
        }
    }

    public void deleteStoryBook(StoryBook ob) {
        for (int i = 0; i < count; i++) {
            if (b2[i] == ob) {
                b2[i] = b2[--count];
                break;
            }
        }
    }

    public void show() {
        System.out.println("\nAIUB Library Information");
        System.out.println("Library Name: " + libraryName);
        System.out.println("Library Hour: " + libraryHour);

        System.out.println("TextBooks : ");
        for (int i = 0; i < totalCount; i++) {
            b1[i].showDetails();
        }

        System.out.println(" StoryBooks: ");
        for (int i = 0; i < count; i++) {
            b2[i].showDetails();
        }
    }
	public TextBook[] getTextBooks()
	{
    return b1;
    }
	public StoryBook[] getStoryBooks()
	{
    return b2;
    }
}
