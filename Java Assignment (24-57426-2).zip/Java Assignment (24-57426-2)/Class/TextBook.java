package Class;
public class TextBook extends Book {
    private String standard;

    public TextBook() {}

    public TextBook( String bookTitle, String authorName, double price, int availableQuantity, String category) {
        super( bookTitle, authorName, price, availableQuantity);
        this.standard = standard;
    }

    public void setStandard(String standard) { this.standard = standard; }
    public String getStandard() { return standard; }

  
    public void showDetails() {
        
        System.out.println("Title: " + bookTitle);
        System.out.println("Author: " + authorName);
        System.out.println("Price: " + price);
        System.out.println("Available Quantity: " + availableQuantity);
		System.out.println("Standard: " + standard);
    }
}
