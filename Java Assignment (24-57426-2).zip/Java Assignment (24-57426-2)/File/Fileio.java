package File;

import java.io.*;

import Class.*;


public class Fileio {

    private static final String FILE_PATH = "library_books.txt";

    public static void saveBook(TextBook book) {
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(FILE_PATH, true)))) {
            out.println("TextBook:");
            out.println("Title: " + book.getBookTitle());
            out.println("Author: " + book.getAuthorName());
            out.println("Price: " + book.getPrice());
            out.println("Quantity: " + book.getAvailableQuantity());
            out.println("Standard: " + book.getCategory());
            out.println("-----");
        } catch (IOException e) {
            System.err.println("Error writing TextBook to file: " + e.getMessage());
        }
    }

    public static void saveBook(StoryBook book) {
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(FILE_PATH, true)))) {
            out.println("StoryBook:");
            out.println("Title: " + book.getBookTitle());
            out.println("Author: " + book.getAuthorName());
            out.println("Price: " + book.getPrice());
            out.println("Quantity: " + book.getAvailableQuantity());
            out.println("Category: " + book.getCategory());
            out.println("-----");
        } catch (IOException e) {
            System.err.println("Error writing StoryBook to file: " + e.getMessage());
        }
    }
}
