package Gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import Class.*;
import Fileio.*;

public class AIUB_LIbrary_page extends JFrame implements ActionListener {
    private JTextField titleField, authorField, priceField, quantityField, categoryField;
    private JButton addTextBookButton, addStoryBookButton;
    private AiubLibrary library;
    private static final String FILE_PATH = "library_books.txt";

    public AIUB_LIbrary_page() {
        super("AIUB Library Book Entry");
        library = new AiubLibrary("AIUB Central", 10, 100);

        setLayout(new GridLayout(8, 2, 5, 5));

        add(new JLabel("Book Title:"));
        titleField = new JTextField(20);
        add(titleField);

        add(new JLabel("Author Name:"));
        authorField = new JTextField(20);
        add(authorField);

        add(new JLabel("Price:"));
        priceField = new JTextField(20);
        add(priceField);

        add(new JLabel("Available Quantity:"));
        quantityField = new JTextField(20);
        add(quantityField);

        add(new JLabel("Category/Standard:"));
        categoryField = new JTextField(20);
        add(categoryField);

        addTextBookButton = new JButton("Add TextBook");
        addTextBookButton.addActionListener(this);
        add(addTextBookButton);

        addStoryBookButton = new JButton("Add StoryBook");
        addStoryBookButton.addActionListener(this);
        add(addStoryBookButton);

        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e)
	{
        try 
		{
            String title = titleField.getText();
            String author = authorField.getText();
            double price = Double.parseDouble(priceField.getText());
            int quantity = Integer.parseInt(quantityField.getText());
            String category = categoryField.getText();

            if (e.getSource() == addTextBookButton)
			{
             TextBook tb = new TextBook(title, author, price, quantity, category);
                    tb.setCategory(category);
                    library.addTextBook(tb);
                      FileManager.saveBook(tb); // overloaded
            }
			else if (e.getSource() == addStoryBookButton)
			{
                     StoryBook sb = new StoryBook(title, author, price, quantity, category);
                       sb.setCategory(category);
                       library.addStoryBook(sb);
                        FileManager.saveBook(sb); // overloaded
            }

            JOptionPane.showMessageDialog(this, "Book added and saved to file!");
            clearFields();
        }
		catch (NumberFormatException ex)
		{
            JOptionPane.showMessageDialog(this, "Invalid number input!");
        }
    }

    private void clearFields()
	{
        titleField.setText("");
        authorField.setText("");
        priceField.setText("");
        quantityField.setText("");
        categoryField.setText("");
    }

}  
