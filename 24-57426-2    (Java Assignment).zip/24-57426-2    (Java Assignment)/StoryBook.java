public class StoryBook extends Book
{
    private String storyBooks;

    public StoryBook(String bookName, String writer, double value, int stock, String storyBooks)
	{
        super(bookName, writer, value, stock);
        this.storyBooks = storyBooks;
    }

    public void showDetails()
	{
        System.out.println("StoryBook: " + bookName + ", " + writer + ", " + value + " $ , " + availableStock + " ,Category Of The Book : " + storyBooks);
    }

    public String toString()
	{
        return "StoryBook: " + bookName + ", " + writer + ", " + value + " $ , " + availableStock + " , Category Of The Book : " + storyBooks;
    }
}