public abstract class Book
{
    protected String bookName;
    protected String writer;
    protected double value;
    protected int availableStock;

    public Book()
	{  
	  System.out.println("Default Book Constructor");
	}

    public Book(String bookName, String writer, double value, int stock)
	{
        this.bookName = bookName;
        this.writer = writer;
        this.value = value;
        this.availableStock = stock;
    }

    public void addQuantity(int amount)
	{
        this.availableStock += amount;
    }

    public void sellQuantity(int amount)
	{
        if (amount <= availableStock)
		{
            this.availableStock -= amount;
        }
    }
	
	public boolean equals(Object obj)
	{
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Book book = (Book) obj;
        return bookName.equals(book.bookName) && writer.equals(book.writer);
                                           
    }

    public abstract void showDetails();
}