public class AiubLibrary
{
    private String name;
    private int floorNumber;
    private Book[] books = new Book[100];
    private int totalBooks = 0;

    public AiubLibrary(String name, int floorNumber, int size)
	{
        this.name = name;
        this.floorNumber = floorNumber;
        this.books = new Book[size];
    }

    public void insertBook(Book b)
	{
        if (totalBooks < books.length)
		{
            books[totalBooks] = b;
			totalBooks++;
        } 
		else
		{
            System.out.println("Library is full.");
        }
    }
	public void deleteBook(Book b)
	{
		for(int i=0;i<totalBooks;i++)
		{
			if (books[i].equals(b))
			{
			 books[i]=books[--totalBooks];
			 books[totalBooks]=null;
			 System.out.println("The Book Has Been Deleted!!");
			 return;
			}
		}
		 System.out.println("Book not found.");
		
	}

    public void showAllBooks()
	{
        for (int i = 0; i < totalBooks; i++) 
		{
            books[i].showDetails();
        }
    }
	public void deleteAllBooks()
	{
        for (int i = 0; i < totalBooks; i++) 
		{
            books[i]=null;
			
        }
		totalBooks=0;
		System.out.println("All books deleted.");
    }
}