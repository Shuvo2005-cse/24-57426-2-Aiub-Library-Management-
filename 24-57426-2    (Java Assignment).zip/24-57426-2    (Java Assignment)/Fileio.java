import java.io.*;
import java.util.*;

public class Fileio
{
    public void writeInFile(String s)
	{
        try {
            FileWriter fw = new FileWriter("library_output.txt", true);
            fw.write(s + "\n");
            fw.close();
        }
		catch (IOException e)
		{
            System.out.println(e);
        }
    }

    // New method to delete a specific book entry
    public void deleteFromFile(String s)
	{
        File inputFile = new File("library_output.txt");
        File tempFile = new File("temp_library_output.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String currentLine;

            while ((currentLine = reader.readLine()) != null)
			{
                // Trim and compare the line to be removed
                if (!currentLine.trim().equals(s.trim()))
				{
                    writer.write(currentLine + System.lineSeparator());
                }
            }
        }
		catch (IOException e)
		{
            System.out.println("Error occurred while deleting: " + e);
        }

        // Replace original file with the temp file
        if (inputFile.delete()) {
            tempFile.renameTo(inputFile);
        }
    }
}

















/*import java.io.*;

public class Fileio {
    public void writeInFile(String s) {
        try {
            FileWriter f1 = new FileWriter("library_output.txt", true);
            f1.write(s + "\n");
            f1.close();
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }

    public void readFromFile() {
        try {
            FileReader fr = new FileReader("library_output.txt");
            int i;
            while ((i = fr.read()) != -1) {
                System.out.print((char) i);
            }
            fr.close();
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }
}*/