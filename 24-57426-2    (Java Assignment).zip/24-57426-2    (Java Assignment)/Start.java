public class Start
{
    public static void main(String[] args)
	{
        AiubLibraryPage app = new AiubLibraryPage();
    }
}