import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon.*;

public class AiubLibraryPage extends JFrame implements ActionListener
{
    private JTextField titleField, authorField, priceField, quantityField, categoryField,updateField,updateAllField;
    private JButton addTextBookBtn, addStoryBookBtn, showAllBooksBtn,deleteTextBooksBtn,deleteStoryBooksBtn,deleteAllBooksBtn,updateSpecificBtn,updateAllBtn;
    private AiubLibrary library;
    private JLabel titleLabel,authorLabel,priceLabel,stockLabel,categoryLabel,updateLabel,updateAllLabel;
    
	
	public AiubLibraryPage()
	{
        library = new AiubLibrary("AIUB Central", 10, 100);

        setTitle("AIUB Library Management System");
        setSize(800,800);
        setLayout(new GridLayout(11, 2));
		
		ImageIcon image = new ImageIcon("aiublogo.png");
		this.setIconImage(image.getImage());
		this.getContentPane().setBackground(new Color(0x123456));
		//this.setResizable(false);
		
		Font labelFont = new Font("Times New Roman",Font.BOLD,22);
		Color labelColor = Color.WHITE;
		Color label_background_colour= Color.BLUE;
		
		Font fieldFont = new Font("Times New Roman",Font.BOLD,20);
		Color fieldColor = Color.BLACK;
        Color backgroundColor= new Color(173,216,230);
		
		Font buttonfont = new Font("Times New Roman",Font.BOLD,22);
		Color deleteButtons_Background_Color = new Color(139,0,0);
        Color deleteButtons_Foreground_Color = Color.BLACK;


        titleField = new JTextField();
		titleField.setFont(fieldFont);
		titleField.setForeground(fieldColor);
		titleField.setBackground(backgroundColor);
		
		
        authorField = new JTextField();
		authorField.setFont(fieldFont);
		authorField.setForeground(fieldColor);
		authorField.setBackground(backgroundColor);
		
        priceField = new JTextField();
		priceField.setFont(fieldFont);
		priceField.setForeground(fieldColor);
		priceField.setBackground(backgroundColor);
		
		
        quantityField = new JTextField();
		quantityField.setFont(fieldFont);
		quantityField.setForeground(fieldColor);
		quantityField.setBackground(backgroundColor);
		
		
        categoryField = new JTextField();
		categoryField.setFont(fieldFont);
		categoryField.setForeground(fieldColor);
		categoryField.setBackground(backgroundColor);
		
		updateField = new JTextField();
		updateField.setFont(fieldFont);
		updateField.setForeground(fieldColor);
		updateField.setBackground(backgroundColor);
		
		updateAllField = new JTextField();
		updateAllField.setFont(fieldFont);
		updateAllField.setForeground(fieldColor);
		updateAllField.setBackground(backgroundColor);
		
          
		  
        addTextBookBtn = new JButton("Add TextBook");
		addTextBookBtn.setFont(buttonfont);
		
        addStoryBookBtn = new JButton("Add StoryBook");
		addStoryBookBtn.setFont(buttonfont);
		
		updateSpecificBtn=new JButton("Update Specific Book");
		updateSpecificBtn.setFont(buttonfont);
		
		updateAllBtn=new JButton("Update All");
		updateAllBtn.setFont(buttonfont);
		
        showAllBooksBtn = new JButton("Show All Books");
		showAllBooksBtn.setFont(buttonfont);
		
		deleteTextBooksBtn = new JButton("Delete The Text Book!");
		deleteTextBooksBtn.setFont(buttonfont);
		deleteTextBooksBtn.setBackground(deleteButtons_Background_Color);
		deleteTextBooksBtn.setForeground(deleteButtons_Foreground_Color);
		
		deleteStoryBooksBtn = new JButton("Delete The Story Book!");
		deleteStoryBooksBtn.setFont(buttonfont);
		deleteStoryBooksBtn.setForeground(deleteButtons_Foreground_Color);
		deleteStoryBooksBtn.setBackground(deleteButtons_Background_Color);
		
        deleteAllBooksBtn = new JButton("Delete All Books!");
		deleteAllBooksBtn.setFont(buttonfont);
		deleteAllBooksBtn.setBackground(deleteButtons_Background_Color);
		deleteAllBooksBtn.setForeground(deleteButtons_Foreground_Color);
        
		
		titleLabel = new JLabel("Title :");
		titleLabel.setFont(labelFont);
		titleLabel.setForeground(labelColor);
		titleLabel.setBackground(label_background_colour);
		add(titleLabel); 
		add(titleField);
        
		authorLabel = new JLabel("Writer :");
		authorLabel.setFont(labelFont);
		authorLabel.setForeground(labelColor);
		authorLabel.setBackground(label_background_colour);
		add(authorLabel);
		add(authorField);
        
		priceLabel = new JLabel("Price :");
		priceLabel.setFont(labelFont);
		priceLabel.setForeground(labelColor);
		priceLabel.setBackground(label_background_colour);
		add(priceLabel);
		add(priceField);
		
		
        stockLabel = new JLabel("Current This Book Stock :");
		stockLabel.setFont(labelFont);
		stockLabel.setForeground(labelColor);
		stockLabel.setBackground(label_background_colour);
        add(stockLabel);
		add(quantityField);
		
		
		categoryLabel = new JLabel("The Category Of This Book :");
		categoryLabel.setFont(labelFont);
		categoryLabel.setForeground(labelColor);
		categoryLabel.setBackground(label_background_colour);
        add(categoryLabel);
		add(categoryField);
		
		updateLabel = new JLabel("Update Specific Book");
		updateLabel.setFont(labelFont);
		updateLabel.setForeground(labelColor);
		updateLabel.setBackground(label_background_colour);
		add(updateLabel);
		add(updateField);
		
		updateAllLabel = new JLabel("Update All Book");
		updateAllLabel.setFont(labelFont);
		updateAllLabel.setForeground(labelColor);
		updateAllLabel.setBackground(label_background_colour);
		add(updateAllLabel);
		add(updateAllField);
		
		
        add(addTextBookBtn);
		add(addStoryBookBtn);
		add(showAllBooksBtn);
		add(updateSpecificBtn);
		add(updateAllBtn);
		add(deleteTextBooksBtn);
		add(deleteStoryBooksBtn);
		add(deleteAllBooksBtn);
		
		
        addTextBookBtn.addActionListener(this);
        addStoryBookBtn.addActionListener(this);
        showAllBooksBtn.addActionListener(this);
		updateSpecificBtn.addActionListener(this);
		updateAllBtn.addActionListener(this);
        deleteTextBooksBtn.addActionListener(this);
		deleteStoryBooksBtn.addActionListener(this);
		deleteAllBooksBtn.addActionListener(this);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
		
    }

    public void actionPerformed(ActionEvent e)
	{
        String title = titleField.getText();
        String author = authorField.getText();
        double price = Double.parseDouble(priceField.getText());
        int quantity = Integer.parseInt(quantityField.getText());
        String category = categoryField.getText();

        if (e.getSource() == addTextBookBtn)
		{
            TextBook tb = new TextBook(title, author, price, quantity, category);
            library.insertBook(tb);
			
            new Fileio().writeInFile(tb.toString());
        } 
		else if (e.getSource() == addStoryBookBtn)
		{
            StoryBook sb = new StoryBook(title, author, price, quantity, category);
            library.insertBook(sb);
			
            new Fileio().writeInFile(sb.toString());
		}	
		else if (e.getSource() == deleteTextBooksBtn)
		{
             TextBook tb1 = new TextBook(title, author, price, quantity, category);
            
			library.deleteBook(tb1);
           new Fileio().deleteFromFile(tb1.toString());
        }
		else if (e.getSource() == deleteStoryBooksBtn)
		{
            StoryBook sb1 = new StoryBook(title, author, price, quantity, category);
            
			library.deleteBook(sb1);
            new Fileio().deleteFromFile(sb1.toString());
        }
		
		else if (e.getSource() == showAllBooksBtn)
		{
            library.showAllBooks();
        }
		else if (e.getSource() == deleteAllBooksBtn)
		{
            library.deleteAllBooks();
        }
   
    }
}