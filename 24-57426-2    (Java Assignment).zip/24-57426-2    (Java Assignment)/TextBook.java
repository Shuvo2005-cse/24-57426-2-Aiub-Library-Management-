public class TextBook extends Book
{
    private String textBook;

    public TextBook(String bookName, String  writer, double value, int stock, String textBook)
	{
        super(bookName, writer, value,stock);
        this.textBook = textBook;
    }

    public void showDetails()
	{
        System.out.println("TextBook: " + bookName + ", " + writer + " $ , " +value + ", " + availableStock + " , Category Of The Book : " +textBook);
    }

    public String toString()
	{
        return "TextBook: " + bookName + ", " + writer + ", " + value + " $ , " + availableStock + " Category Of The Book :" + textBook;
    }
}